package PA2;

class ListNode {

	public int value;
	public ListNode next;

	public ListNode(int val) {
		value = val;
		next = null;
	}
}
